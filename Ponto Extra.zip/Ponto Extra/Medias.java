public class Medias {
    public static void main(String[] args) {
        int num1 = 8;
        int num2 = 9;
        int num3 = 7;
        double media1 = (num1 + num2 + num3) / 3.0;
        System.out.println("A média dos números " + num1 + ", " + num2 + " e " + num3 + " é: " + media1);
        
        int num4 = 4;
        int num5 = 5;
        int num6 = 6;
        double media2 = (num4 + num5 + num6) / 3.0;
        System.out.println("A média dos números " + num4 + ", " + num5 + " e " + num6 + " é: " + media2);
        
        double somaMedias = media1 + media2;
        System.out.println("A soma das duas médias é: " + somaMedias);
        
        double mediaMedias = (media1 + media2) / 2.0;
        System.out.println("A média das médias é: " + mediaMedias);
    }
}

