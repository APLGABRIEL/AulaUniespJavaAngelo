public class AntecessorSucessor {
    private int numero;

    public AntecessorSucessor(int numero) {
        this.numero = numero;
    }

    public void imprimirAntecessorSucessor() {
        int antecessor = numero - 1;
        int sucessor = numero + 1;
        System.out.println("O antecessor de " + numero + " é " + antecessor);
        System.out.println("O sucessor de " + numero + " é " + sucessor);
    }

    public static void main(String[] args) {
        AntecessorSucessor antecessorSucessor = new AntecessorSucessor(10);
        antecessorSucessor.imprimirAntecessorSucessor();
    }
}
