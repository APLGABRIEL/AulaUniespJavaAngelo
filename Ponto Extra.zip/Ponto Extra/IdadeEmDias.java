

public class IdadeEmDias {
    private int anos;
    private int meses;
    private int dias;
    
    public IdadeEmDias(int anos, int meses, int dias) {
        this.anos = anos;
        this.meses = meses;
        this.dias = dias;
    }
    
    public int calcularIdadeEmDias() {
        int idadeEmDias = 0;
        idadeEmDias += anos * 365;
        idadeEmDias += meses * 30;
        idadeEmDias += dias;
        return idadeEmDias;
    }
    
    public static void main(String[] args) {
        IdadeEmDias idade = new IdadeEmDias(25, 6, 15);
        int idadeEmDias = idade.calcularIdadeEmDias();
        System.out.println("A idade em dias é: " + idadeEmDias);
    }
}
