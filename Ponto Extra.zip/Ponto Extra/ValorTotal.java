public class ValorTotal {
    private double ipi;
    private int codigo1;
    private double valorUnitario1;
    private int quantidade1;
    private int codigo2;
    private double valorUnitario2;
    private int quantidade2;

    public ValorTotal(double ipi, int codigo1, double valorUnitario1, int quantidade1, int codigo2, double valorUnitario2, int quantidade2) {
        this.ipi = ipi;
        this.codigo1 = codigo1;
        this.valorUnitario1 = valorUnitario1;
        this.quantidade1 = quantidade1;
        this.codigo2 = codigo2;
        this.valorUnitario2 = valorUnitario2;
        this.quantidade2 = quantidade2;
    }

    public double calcularValorTotal() {
        double valorTotal = (valorUnitario1 * quantidade1 + valorUnitario2 * quantidade2) * (ipi / 100 + 1);
        return valorTotal;
    }

    public static void main(String[] args) {
        ValorTotal valorTotal = new ValorTotal(10, 1, 50, 2, 2, 75, 1);
        System.out.println("Valor total a ser pago: " + valorTotal.calcularValorTotal());
    }
}

