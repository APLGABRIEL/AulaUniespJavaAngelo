public class SalariosMinimos {
    private double salarioMinimo;
    private double salarioUsuario;

    public SalariosMinimos(double salarioMinimo, double salarioUsuario) {
        this.salarioMinimo = salarioMinimo;
        this.salarioUsuario = salarioUsuario;
    }

    public double calcularSalariosMinimos() {
        double quantidade = salarioUsuario / salarioMinimo;
        return quantidade;
    }

    public static void main(String[] args) {
        SalariosMinimos salariosMinimos = new SalariosMinimos(1320, 2640);
        System.out.println("O usuário ganha " + salariosMinimos.calcularSalariosMinimos() + " salários mínimos.");
    }
}
